DeathDimension V2.1 - Paper 1.21.11

Perubahan V2.1:
- Untuk kematian akibat damage normal, plugin menangkap serangan fatal sebelum pemain benar-benar mati.
- Title "KAMU MATI", suara, blindness/darkness, dan partikel dimulai di lokasi pemain saat itu juga.
- Pemain mendapat efek levitation selama 60 tick (3 detik) sambil partikel jiwa berulang.
- Setelah animasi selesai, barulah pemain dipindahkan ke death_void.
- Jika kematian dipicu plugin lain secara langsung (misalnya setHealth(0)), fallback PlayerDeathEvent hanya dapat memulai title/partikel di lokasi kematian; animasi pemain hidup sebelum teleport tidak selalu dapat dilakukan karena pemain sudah masuk status mati.
- Hukuman 3 jam, /dd reload, /dd send, /dd release tetap tersedia.

Build:
1. Ekstrak ZIP.
2. Jalankan: mvn clean package
3. Ambil JAR dari folder target.

Catatan:
Uji pada server salinan/backup terlebih dahulu. Paper plugin tidak dapat mengganti sepenuhnya layar kematian bawaan client.

Update: lethal damage intercepted by DeathDimension now drops storage inventory, armor, and offhand at the death location before the cinematic. Plugin-driven PlayerDeathEvent also forces keepInventory=false.
