package id.rayhan.deathdimension;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.*;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;

import java.util.*;

public final class DeathDimension extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<UUID, Long> punishments = new HashMap<>();
    private final Set<UUID> activeCinematics = new HashSet<>();
    private final Map<UUID, Float> oldWalkSpeeds = new HashMap<>();
    private final Map<UUID, Boolean> oldInvulnerable = new HashMap<>();
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();
    private BukkitTask ticker;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadPunishments();
        createVoidWorld();
        Objects.requireNonNull(getCommand("deathdimension")).setExecutor(this);
        getServer().getPluginManager().registerEvents(this, this);
        ticker = getServer().getScheduler().runTaskTimer(this, this::tickPunishments, 20L, 20L);
        getLogger().info("DeathDimension V2 enabled.");
    }

    @Override
    public void onDisable() {
        if (ticker != null) ticker.cancel();
        savePunishments();
    }

    private void createVoidWorld() {
        String name = getConfig().getString("void.world", "death_void");
        World world = Bukkit.getWorld(name);
        if (world == null) {
            ChunkGenerator emptyGenerator = new ChunkGenerator() {
                @Override
                public ChunkData generateChunkData(World world, Random random, int x, int z, BiomeGrid biome) {
                    return createChunkData(world);
                }
            };
            world = new WorldCreator(name).environment(World.Environment.NORMAL).generator(emptyGenerator).createWorld();
        }
        if (world == null) {
            getLogger().severe("Gagal membuat world void: " + name);
            return;
        }
        world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        world.setTime(18000);
        world.setStorm(false);
        world.setThundering(false);
        Location center = voidLocation();
        int radius = Math.max(1, getConfig().getInt("void.platform-radius", 3));
        Material platform;
        try {
            platform = Material.valueOf(getConfig().getString("void.platform-block", "BLACKSTONE").toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            platform = Material.BLACKSTONE;
        }
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                world.getBlockAt(center.getBlockX() + x, center.getBlockY() - 1, center.getBlockZ() + z).setType(platform, false);
            }
        }
        world.setSpawnLocation(center);
    }

    private Location voidLocation() {
        World world = Bukkit.getWorld(getConfig().getString("void.world", "death_void"));
        if (world == null) return Bukkit.getWorlds().get(0).getSpawnLocation();
        return new Location(world,
                getConfig().getDouble("void.x", 0.5),
                getConfig().getDouble("void.y", 80.0),
                getConfig().getDouble("void.z", 0.5),
                0f, 0f);
    }

    // Intercept lethal damage so the cinematic begins BEFORE the player is actually dead
    // and before teleporting to death_void.
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onLethalDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        UUID id = player.getUniqueId();
        if (activeCinematics.contains(id)) {
            event.setCancelled(true);
            return;
        }

        double remainingHealth = player.getHealth() + player.getAbsorptionAmount();
        if (event.getFinalDamage() < remainingHealth) return;

        event.setCancelled(true);
        beginDeathSequence(player);
    }

    private void beginDeathSequence(Player player) {
        UUID id = player.getUniqueId();
        if (!activeCinematics.add(id)) return;

        long expiry = System.currentTimeMillis()
                + getConfig().getLong("punishment-seconds", 10800) * 1000L;
        punishments.put(id, expiry);
        savePunishments();

        oldWalkSpeeds.put(id, player.getWalkSpeed());
        oldInvulnerable.put(id, player.isInvulnerable());
        player.setInvulnerable(true);
        player.setWalkSpeed(0.0f);
        player.closeInventory();

        // The lethal hit is cancelled, so this is the single authoritative drop pass.
        // Items are cloned into the world and then removed from every player slot.
        dropPlayerItems(player);

        Location cameraOrigin = player.getLocation().clone();
        float startYaw = cameraOrigin.getYaw();
        float startPitch = cameraOrigin.getPitch();
        showDeathStartEffects(player);

        // 100 ticks = 5 seconds. The camera is animated by smoothly rotating the
        // player's view while the body rises; Paper cannot move a separate client camera.
        final int duration = Math.max(20, getConfig().getInt("cinematic.animation-ticks", 100));
        player.addPotionEffect(new PotionEffect(
                PotionEffectType.LEVITATION, duration + 5, 0, false, false, true));
        player.addPotionEffect(new PotionEffect(
                PotionEffectType.SLOW_FALLING, duration + 5, 0, false, false, true));

        final int[] elapsed = {0};
        Bukkit.getScheduler().runTaskTimer(this, task -> {
            if (!player.isOnline()) {
                task.cancel();
                activeCinematics.remove(id);
                oldWalkSpeeds.remove(id);
                oldInvulnerable.remove(id);
                return;
            }

            int tick = elapsed[0];
            // Cinematic camera sweep: gentle orbit and tilt, following the floating player.
            double progress = Math.min(1.0, tick / (double) duration);
            float yaw = (float) (startYaw + Math.sin(progress * Math.PI * 2.0) * 22.0);
            float pitch = (float) Math.max(-65.0, Math.min(65.0,
                    startPitch - Math.sin(progress * Math.PI) * 18.0));
            player.setRotation(yaw, pitch);

            spawnDeathParticles(player, tick);
            if (tick == 30) {
                player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.9f, 0.7f);
            }
            if (tick == duration - 5) {
                player.playSound(player.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 1.0f, 0.65f);
                player.getWorld().spawnParticle(Particle.FLASH, player.getLocation().add(0, 1, 0), 1);
                player.getWorld().spawnParticle(Particle.REVERSE_PORTAL, player.getLocation().add(0, 1, 0), 90, 0.8, 1.0, 0.8, 0.08);
            }

            elapsed[0] += 5;
            if (elapsed[0] >= duration) {
                task.cancel();
                player.removePotionEffect(PotionEffectType.LEVITATION);
                player.removePotionEffect(PotionEffectType.SLOW_FALLING);
                player.teleport(voidLocation());
                player.setWalkSpeed(oldWalkSpeeds.getOrDefault(id, 0.2f));
                player.setInvulnerable(oldInvulnerable.getOrDefault(id, false));
                oldWalkSpeeds.remove(id);
                oldInvulnerable.remove(id);
                activeCinematics.remove(id);
                player.sendMessage(legacy.deserialize("&8Jiwamu telah dibawa ke Death Dimension."));
            }
        }, 0L, 5L);
    }


    private void dropPlayerItems(Player player) {
        Location dropLocation = player.getLocation().clone();
        org.bukkit.inventory.PlayerInventory inventory = player.getInventory();

        for (org.bukkit.inventory.ItemStack item : inventory.getStorageContents()) {
            if (item != null && !item.getType().isAir()) {
                dropLocation.getWorld().dropItemNaturally(dropLocation, item.clone());
            }
        }
        for (org.bukkit.inventory.ItemStack item : inventory.getArmorContents()) {
            if (item != null && !item.getType().isAir()) {
                dropLocation.getWorld().dropItemNaturally(dropLocation, item.clone());
            }
        }
        org.bukkit.inventory.ItemStack offhand = inventory.getItemInOffHand();
        if (offhand != null && !offhand.getType().isAir()) {
            dropLocation.getWorld().dropItemNaturally(dropLocation, offhand.clone());
        }

        inventory.clear();
        inventory.setArmorContents(null);
        inventory.setItemInOffHand(null);
    }

    // Fallback for plugin-driven deaths: effects are sent at the death location immediately.
    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        UUID id = player.getUniqueId();
        if (activeCinematics.contains(id)) return;

        // For deaths initiated by another plugin, force normal item drops too.
        event.setKeepInventory(false);

        long expiry = System.currentTimeMillis()
                + getConfig().getLong("punishment-seconds", 10800) * 1000L;
        punishments.put(id, expiry);
        savePunishments();
        showDeathStartEffects(player);

        if (getConfig().getBoolean("cinematic.auto-respawn", true)) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (player.isOnline() && player.isDead()) {
                    try {
                        player.spigot().respawn();
                    } catch (Throwable ex) {
                        getLogger().warning("Auto-respawn tidak didukung server ini; pemain perlu menekan Respawn.");
                    }
                }
            }, 2L);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRespawn(PlayerRespawnEvent event) {
        if (!punishments.containsKey(event.getPlayer().getUniqueId())) return;
        event.setRespawnLocation(voidLocation());
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (player.isOnline()) player.teleport(voidLocation());
        }, 2L);
    }

    private void showDeathStartEffects(Player player) {
        // Short darkness gives a brief fainting moment without hiding the full sequence.
        int blind = getConfig().getInt("cinematic.blindness-ticks", 12);
        int dark = getConfig().getInt("cinematic.darkness-ticks", 20);
        if (blind > 0) player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, blind, 0, false, false, false));
        if (dark > 0) player.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, dark, 0, false, false, false));

        String title = getConfig().getString("cinematic.title", "&4&lKAMU MATI");
        String subtitle = getConfig().getString("cinematic.subtitle", "&7Jiwamu telah meninggalkan dunia ini...");
        player.showTitle(net.kyori.adventure.title.Title.title(
                legacy.deserialize(title),
                legacy.deserialize(subtitle),
                net.kyori.adventure.title.Title.Times.times(
                        java.time.Duration.ofMillis(getConfig().getLong("cinematic.title-fade-in", 0) * 50),
                        java.time.Duration.ofMillis(getConfig().getLong("cinematic.title-stay", 100) * 50),
                        java.time.Duration.ofMillis(getConfig().getLong("cinematic.title-fade-out", 20) * 50)
                )
        ));

        // Sound 1: exactly when lethal damage is intercepted.
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_DEATH, 1.0f, 0.8f);
        spawnDeathParticles(player, 0);
    }


    private void playDeathCinematic(Player player) {
        showDeathStartEffects(player);
        player.sendMessage(legacy.deserialize("&8Sebuah kekuatan menarik jiwamu ke dimensi kehampaan..."));
    }

    private void spawnDeathParticles(Player player, int tick) {
        if (!getConfig().getBoolean("cinematic.particles", true)) return;
        Location loc = player.getLocation().clone().add(0, 1.0, 0);
        World world = player.getWorld();

        // Persistent soul aura + sculk energy + smoke.
        world.spawnParticle(Particle.SOUL, loc, 18, 0.55, 0.75, 0.55, 0.025);
        world.spawnParticle(Particle.SCULK_SOUL, loc, 10, 0.4, 0.65, 0.4, 0.02);
        world.spawnParticle(Particle.SMOKE, loc, 8, 0.45, 0.55, 0.45, 0.015);
        world.spawnParticle(Particle.PORTAL, loc, 24, 0.7, 0.9, 0.7, 0.15);
        world.spawnParticle(Particle.ENCHANT, loc, 16, 0.6, 0.8, 0.6, 0.5);

        // Stronger energy pulses every second; lightning is only an accent, not the sole effect.
        if (tick % 20 == 0) {
            world.spawnParticle(Particle.ELECTRIC_SPARK, loc, 35, 0.8, 1.0, 0.8, 0.08);
            world.spawnParticle(Particle.WITCH, loc, 22, 0.65, 0.9, 0.65, 0.04);
            world.spawnParticle(Particle.END_ROD, loc, 12, 0.45, 0.8, 0.45, 0.03);
        }
        if (tick == 0) {
            world.spawnParticle(Particle.EXPLOSION, loc, 1);
            world.spawnParticle(Particle.CLOUD, loc, 35, 0.65, 0.3, 0.65, 0.08);
        }
    }


    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        Long expiry = punishments.get(player.getUniqueId());
        if (expiry != null && expiry > System.currentTimeMillis()) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (player.isOnline()) {
                    player.teleport(voidLocation());
                    player.sendMessage(legacy.deserialize("&8Kamu masih berada dalam hukuman Death Dimension."));
                }
            }, 10L);
        } else if (expiry != null) {
            punishments.remove(player.getUniqueId());
            savePunishments();
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // Waktu hukuman tetap berjalan saat pemain offline.
    }

    private void tickPunishments() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, Long>> iterator = punishments.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Long> entry = iterator.next();
            Player player = Bukkit.getPlayer(entry.getKey());
            long remaining = entry.getValue() - now;
            if (remaining <= 0) {
                iterator.remove();
                if (player != null && player.isOnline()) {
                    player.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
                    player.clearTitle();
                    player.removePotionEffect(PotionEffectType.BLINDNESS);
                    player.removePotionEffect(PotionEffectType.DARKNESS);
                    player.sendMessage(legacy.deserialize("&aWaktumu di Death Dimension telah berakhir."));
                    player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1.0f);
                }
            } else if (player != null && player.isOnline()) {
                String actionbar = getConfig().getString("cinematic.actionbar", "&8Kembali ke dunia dalam &c%time%");
                player.sendActionBar(legacy.deserialize(actionbar.replace("%time%", formatTime(remaining))));
                if (getConfig().getBoolean("cinematic.particles", true) && Math.random() < 0.25) {
                    player.getWorld().spawnParticle(Particle.SOUL, player.getLocation().add(0, 1, 0), 3, 0.35, 0.5, 0.35, 0.01);
                }
            }
        }
        savePunishments();
    }

    private String formatTime(long millis) {
        long seconds = Math.max(0, millis / 1000);
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        return String.format(Locale.ROOT, "%02d:%02d:%02d", hours, minutes, secs);
    }

    private void loadPunishments() {
        punishments.clear();
        var section = getConfig().getConfigurationSection("punishments");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            try {
                punishments.put(UUID.fromString(key), section.getLong(key));
            } catch (IllegalArgumentException ignored) {
                getLogger().warning("UUID hukuman tidak valid: " + key);
            }
        }
    }

    private void savePunishments() {
        getConfig().set("punishments", null);
        for (Map.Entry<UUID, Long> entry : punishments.entrySet()) {
            getConfig().set("punishments." + entry.getKey(), entry.getValue());
        }
        saveConfig();
    }

    private String color(String text) {
        return text == null ? "" : text.replace('&', '§');
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("deathdimension.admin")) {
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.no-permission", "&cKamu tidak punya izin.")));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.usage")));
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.reloaded")));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.usage")));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(Component.text("Pemain tidak ditemukan.", NamedTextColor.RED));
            return true;
        }
        if (args[0].equalsIgnoreCase("release")) {
            if (punishments.remove(target.getUniqueId()) == null) {
                sender.sendMessage(legacy.deserialize(getConfig().getString("messages.no-punishment")));
                return true;
            }
            savePunishments();
            target.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
            target.clearTitle();
            target.removePotionEffect(PotionEffectType.BLINDNESS);
            target.removePotionEffect(PotionEffectType.DARKNESS);
            target.sendMessage(legacy.deserialize(getConfig().getString("messages.released")));
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.released")));
            return true;
        }
        if (args[0].equalsIgnoreCase("send")) {
            punishments.put(target.getUniqueId(), System.currentTimeMillis() + getConfig().getLong("punishment-seconds", 10800) * 1000L);
            savePunishments();
            target.teleport(voidLocation());
            playDeathCinematic(target);
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.sent")));
            return true;
        }
        sender.sendMessage(legacy.deserialize(getConfig().getString("messages.usage")));
        return true;
    }
}
